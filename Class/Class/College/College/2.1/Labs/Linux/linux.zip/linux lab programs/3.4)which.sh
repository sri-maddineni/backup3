c=0
for i in `echo $PATH|sed 's/:/ /g'`
do
if [ -f $i/$1 ]
then
c=`expr $c + 1`
echo "path of command is :$i/$1"
fi
done
if [ $c -eq 0 ]
then
echo "file not found"
fi

