
if [ $1 == $2 ]
then
echo "Two Files are Same"
else
d=`diff $1 $2`
if [ -z $d ]
then
rm $2
echo "Second file Removed"
else
echo "The Contents of the files are not same"
fi
fi

