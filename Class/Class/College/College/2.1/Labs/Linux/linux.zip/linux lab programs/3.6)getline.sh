if [ $# -eq 4 -a $1=="-f" -a $3=="-n" ] 
then 
sed -n $4p $2 
elif [ $# -eq 2 -a $1=="-f" ] 
then 
cat $2 
elif [ $# -eq 4 -a $1=="-n" -a $3=="-f" ] 
then 
sed -n $2 p $4 
else 
echo "Syntax Error" 
fi 
