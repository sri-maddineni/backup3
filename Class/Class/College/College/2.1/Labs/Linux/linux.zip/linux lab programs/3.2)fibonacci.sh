#!/bin/sh
echo the first 25 fibonaci numbers are
num1=0
num2=1
printf " $num1 \t $num2 \t"
count=3
while [ $count -le 25 ]
do
num3=`expr $num1 + $num2`
printf "$num3 \t"
num1=$num2
num2=$num3
count=`expr $count + 1`
done

