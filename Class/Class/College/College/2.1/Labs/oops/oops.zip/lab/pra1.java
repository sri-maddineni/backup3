import java.io.*;

class pra1{
	public static void main(String args[]) throws IOException
	{
		int ch;
		FileInputStream fin=null;
		FileOutputStream fout=null;
		try
		{
			fin=new FileInputStream("C:/Users/91630/alpha.txt");
			fout=new FileOutputStream("C:/Users/91630/newalpha.txt");
			
			ch=fin.read();
			while(ch!=-1)
			{
				fout.write((char)ch);
				ch=fin.read();
				
			}
			System.out.println("file  found");
		}
		catch(Exception e)
		{
			System.out.println("file not found");
		}
		
	}
}
			
		