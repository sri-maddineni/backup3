class A
{
	public int i;
	protected int j=3;
}

class B extends A
{
	int j;
	void display()
	{
		
		System.out.println(i+" "+super.j);
	}
}

class out
{
	public static void main(String args[])
	{
		B obj=new B();
		obj.i=6;
		obj.j=18;
		obj.display();
	}
}