class Vehicle{
  void run(){System.out.println("Vehicle is running");}
  }


  class bb extends Vehicle{
  void run()
{ System.out.println("bike running");}
}


class Bike{
  public static void main(String args[]){
  Vehicle obj = new Vehicle();
  obj.run();
  }
}
