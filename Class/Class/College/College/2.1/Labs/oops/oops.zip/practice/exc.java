import javax.swing.*;
import java.awt.event.*;


public class exc extends JFrame implements ActionListener
{
	JLabel l;
	JCheckBox cb1,cb2,cb3;
	JButton b;
	
	exc()
	{
		l=new JLabel("Food order");
		l.setBounds(20,20,100,50);
		
		cb1=new JCheckBox("pizza @ 100");
		cb1.setBounds(20,50,200,50);
		cb2=new JCheckBox("Burger @ 130 ");
		cb2.setBounds(20,90,200,50);
		cb3=new JCheckBox("Tea @ 10");
		cb3.setBounds(20,130,200,50);
		b=new JButton("order");
		b.setBounds(20,200,100,30);
		
		add(l);
		add(cb1);
		add(cb2);
		add(cb3);
		add(b);
		
		b.addActionListener(this);
		setLayout(null);
		setVisible(true);
		setSize(400,400);
		
	}
	
		public void actionPerformed(ActionEvent e)
		{
			float amount=0;
			String msg="";
			
			if(cb1.isSelected())
			{
				amount+=100;
				msg+="Pizza : 100\n";
			}
			
			if(cb2.isSelected())
			{
				amount+=130;
				msg+="Burger : 130\n";
			}
			
			if(cb3.isSelected())
			{
				amount+=10;
				msg+="Tea : 10\n";
			}
			
			msg+="__________________\n";
			
			JOptionPane.showMessageDialog(this,msg+"total="+amount);
			
		}
	
		
	public static void main(String[] args)
	{
		new exc();
	}
	
}